from django.contrib import admin
from .models import Banner,features,trending,most_played,categories,our_shop,category,product,Support,newsletter
# Register your models here.


admin.site.register(Banner)
admin.site.register(features)
admin.site.register(trending)
admin.site.register(most_played)
admin.site.register(categories)
admin.site.register(our_shop)
admin.site.register(category)
admin.site.register(product)
admin.site.register(newsletter)
admin.site.register(Support)



from django.db import models

# Create your models here.

class Banner(models.Model):
    title1 = models.CharField(max_length=255,null=True,blank=True)
    title2 = models.CharField(max_length=255,null=True,blank=True)
    text = models.TextField('text name',null=True,blank=True)
    button = models.CharField('button name',null=True,blank=True)
    price = models.IntegerField('price',null=True,blank=True)
    procent = models.IntegerField('tokos',null=True,blank=True)
    img = models.ImageField('images/',null=True,blank=True)

    def  __str__(self):
        return self.title1
    


class features(models.Model):
    name = models.CharField(max_length=255,null=True,blank=True)
    img = models.ImageField('images/',null=True,blank=True)
    

    def __str__(self):
        return self.name

class trending(models.Model):
    name = models.CharField(max_length=255,null=True,blank=True)
    img = models.ImageField('images/',null=True,blank=True)
    price1 = models.IntegerField('price',null=True,blank=True)
    price2 = models.IntegerField('price',null=True,blank=True)

    def __str__(self):
        return self.name
    

class most_played(models.Model):
    name = models.CharField(max_length=255,null=True,blank=True)
    img = models.ImageField('images/',null=True,blank=True)

    def __str__(self):
        return self.name
    
class categories(models.Model):
    name = models.CharField(max_length=255,null=True,blank=True)
    img = models.ImageField('images/',null=True,blank=True)

    def __str__(self):
        return self.name
    

class our_shop(models.Model):
    title = models.CharField(max_length=255,null=True,blank=True)
    text = models.TextField('text name',null=True,blank=True)
    button = models.CharField('button name',null=True,blank=True)

    def __str__(self):
        return self.title
    


class category(models.Model):
    name = models.CharField('Cat name',max_length=255,null=True,blank=True)

    def __str__(self):
        return self.name
    

class product(models.Model):
    category = models.ForeignKey(category,on_delete=models.CASCADE,related_name='cat_prod')
    name = models.CharField(max_length=255,null=True,blank=True)
    img = models.ImageField('images/',null=True,blank=True)
    price1 = models.IntegerField('price',null=True,blank=True)
    price2 = models.IntegerField('price',null=True,blank=True)

    def __str__(self):
        return self.name
    

class newsletter(models.Model):
    name = models.CharField(max_length=255,null=True,blank=True)
    text = models.TextField('text name',null=True,blank=True)
    button = models.CharField('button name',null=True,blank=True)

    def __str__(self):
        return self.name


class Support(models.Model):
    
    name = models.CharField('Support name',max_length=50)
    email = models.EmailField('Support email')
    text = models.TextField('Support text')
    
    def __str__(self) -> str:
        return self.name
    
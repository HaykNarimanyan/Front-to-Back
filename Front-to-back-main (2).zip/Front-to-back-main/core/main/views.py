from django.shortcuts import render,redirect
from . import models
from django.contrib import messages
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm
from .forms import NewUserForm
# Create your views here.

def Index(request):
    most_list = models.most_played.objects.all()
    categories_list = models.categories.objects.all()
    our_shop = models.our_shop.objects.first()
    trending_list = models.trending.objects.all()
    features_list = models.features.objects.all()
    banner_list = models.Banner.objects.first()
    newsletter_list = models.newsletter.objects.first()
    return render(request,'main/index.html',context={
        'banner_list':banner_list,
        'features_list':features_list,
        'trending_list':trending_list,
        'most_list':most_list,
        'categories_list':categories_list,
        'our_shop':our_shop,
		'newsletter_list':newsletter_list
    })

def Contact(request):
    if request.method == 'POST':
        user_name = request.POST.get('name')
        user_email = request.POST.get('email')
        user_text = request.POST.get('text')
        models.Support.objects.create(name = user_name,email = user_email,text = user_text)
        return redirect('contact')
    return render(request,'main/contact.html',context={
        
    })

def Product(request):
    return render(request,'main/product-details.html',context={
        
    })

def Shop(request):
    category_id = request.GET.get('category')
    category_list = models.category.objects.all()

    if category_id:
        product_list = models.product.objects.filter(category_id=category_id)
    else:
        product_list = models.product.objects.all()

    return render(request, 'main/shop.html', {
        'category_list': category_list,
        'product_list': product_list
    })



def register_request(request):
	if request.method == "POST":
		form = NewUserForm(request.POST)
		if form.is_valid():
			user = form.save()
			login(request, user)
			messages.success(request, "Registration successful." )
			return redirect("index")
		messages.error(request, "Unsuccessful registration. Invalid information.")
	form = NewUserForm()
	return render(request=request, template_name="main/register.html", context={"register_form":form})

def login_request(request):
	if request.method == "POST":
		form = AuthenticationForm(request, data=request.POST)
		if form.is_valid():
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password')
			user = authenticate(username=username, password=password)
			if user is not None:
				login(request, user)
				messages.info(request, f"You are now logged in as {username}.")
				return redirect("index")
			else:
				messages.error(request,"Invalid username or password.")
		else:
			messages.error(request,"Invalid username or password.")
	form = AuthenticationForm()
	return render(request=request, template_name="main/login.html", context={"login_form":form})

def logout_request(request):
	logout(request)
	messages.info(request, "You have successfully logged out.") 
	return redirect("index")